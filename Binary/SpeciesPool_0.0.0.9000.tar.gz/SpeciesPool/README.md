# SpeciesPool
R Package to calculate plot-specific species pools using large vegetation databases

For installing the package in a local Rstudio, use   
library(devtools)  
install_github("idiv-biodiversity/SpeciesPool", ref="master")  
  
Please do not share the token with others
